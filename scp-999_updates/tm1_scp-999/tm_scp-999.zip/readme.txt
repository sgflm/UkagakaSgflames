--Readme--

This is the readme for your ghost. I would highly recommend writing your own readme file in here. Information you might want to include would be your name, your site, the characters you're using, features they may have, places you can be contacted, hotkeys they have set, what kind of conversations they have, or anything else like that that you think your user might like to know.